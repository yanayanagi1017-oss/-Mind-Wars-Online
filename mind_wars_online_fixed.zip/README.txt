Mind Wars Online 修正版

目的: 通信ライブラリの読み込み失敗で画面のボタンまで無反応になる問題を診断しやすくします。
使い方:
1. GitHubの -Mind-Wars-Online リポジトリを開く
2. index.html を開く
3. 鉛筆アイコン(Edit this file)から内容を全選択して、この修正版 index.html の内容に置き換える
4. Commit changes を押す
5. GitHub PagesのURLを再読み込みして「ルームを作る」を押す

注意: これは読み込みエラーを表示するための修正版で、すべての端末・通信環境での動作を保証するものではありません。
